const getWeatherBtn = document.getElementById("get-weather-btn");
const citySelect = document.getElementById("city-select");
const weatherIcon = document.getElementById("weather-icon");
const mainTemp = document.getElementById("main-temperature");
const feelsLike = document.getElementById("feels-like");
const humidity = document.getElementById("humidity");
const wind = document.getElementById("wind");
const windGust = document.getElementById("wind-gust");
const weatherMain = document.getElementById("weather-main");
const locationEl = document.getElementById("location");

async function getWeather(city) {
  try {
    const response = await fetch(`https://weather-proxy.freecodecamp.rocks/api/city/${city}`);
    if (!response.ok) throw new Error("API error");
    const data = await response.json();
    return data;
  } catch (err) {
    console.error(err);
    return undefined;
  }
}

async function showWeather(city) {
  if (!city) return;

  const data = await getWeather(city);
  if (!data) {
    alert("Something went wrong, please try again later.");
    return;
  }

  weatherIcon.src = data.weather?.[0]?.icon || "";
  weatherMain.textContent = data.weather?.[0]?.main || "N/A";
  locationEl.textContent = data.name || "N/A";
  mainTemp.textContent = data.main?.temp ?? "N/A";
  feelsLike.textContent = data.main?.feels_like ?? "N/A";
  humidity.textContent = data.main?.humidity ?? "N/A";
  wind.textContent = data.wind?.speed ?? "N/A";
  windGust.textContent = data.wind?.gust ?? "N/A";
}

getWeatherBtn.addEventListener("click", () => {
  const city = citySelect.value;
  if (!city) return;
  showWeather(city);
});
